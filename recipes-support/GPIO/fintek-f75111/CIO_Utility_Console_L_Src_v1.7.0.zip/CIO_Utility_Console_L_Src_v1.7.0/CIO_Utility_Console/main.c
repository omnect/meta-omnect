#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <getopt.h>
#include <string.h>
#include <signal.h>
#include <sys/time.h>

#include "SMBus/SMBus.h"
#include "f75111.h"

#define OPTIONAL_ARGUMENT_IS_PRESENT \
    ((optarg == NULL && optind < argc && argv[optind][0] != '-') \
     ? (bool) (optarg = argv[optind++]) \
     : (optarg != NULL))

//extern platform Platform;
F75111_Address m_F75111;
BYTE addr;

char program_name[100] = "Sample";

void printf_help(int exval)
{
    printf("************************************************************************************ \n");
	printf("Usage: %s [OPTION] \n\n", program_name);
	printf("\n");
	printf(" [options]\n");
	printf(" -h --help                      Printf this help and exit\n");
	printf(" -w <output_pin_number>         Write output pin number with pin_status\n");
	printf(" -r <input_pin_number>          Read input pin number status\n");
	printf(" -W                             Write all output pin status\n");
	printf(" -R                             Read all input pin status\n");
	printf(" -o                             Use CIO1 module or (CIO1 + CIO2) module DO pin send signal. \n");
    printf("(Send Value: CIO1-DO1:0x01, CIO1-DO2:0x02, CIO1-DO3:0x04, CIO1-DO4:0x08) \n");
	printf(" -s <pin_status>                Pin status = 'h' or 'H' 'l' or 'L', with 'w' or 'r' without parameters, 0x00 - 0xff	\n");
	printf("\n");
	printf("Sample: ./%s -w 1 -s 1          Write output pin 1 write true \n",program_name);
	printf("Sample: ./%s -W -s 0xff         Writeoutput pin all  write true \n",program_name);
	printf("Sample: ./%s -r 1               Read input pin 1	\n",program_name);
	printf("Sample: ./%s -R                 Read input all pin	\n",program_name);
	printf("Sample: ./%s -o 1 -s 1          Use CIO1 module DO-0 pin (0x01) send signal.	\n", program_name);
	printf("Sample: ./%s -o 1 -s 3          Use CIO1 module DO-0 and DO-1 pin (0x01 + 0x02) send signal.	\n", program_name);
	printf("Sample: ./%s -o 1 -s f          Use CIO1 module DO-0, DO-1, DO-2 and DO-3 pin (0x01 + 0x02 + 0x04 + 0x08) send signal.	\n", program_name);
	printf("Sample: ./%s -o 2 -s 1          Use (CIO1 + CIO2) module DO-0 pin (0x01) send signal.	\n", program_name);
	printf("Sample: ./%s -o 2 -s 11         Use (CIO1 + CIO2) module DO-0 and DO-4 pin (0x01 + 0x10) send signal.	\n", program_name);
	printf("************************************************************************************ \n");

	//SMBus_Uninstall();
	exit(exval);
}

int htoi(char *p)
{
       /*
        * Look for 'x' as second character as in '0x' format
        */
       if ((p[1] == 'x')  || (p[1] == 'X'))
               return(strtol(&p[2], (char **)0, 16));
       else
               return(strtol(p, (char **)0, 16));
}

int DioRange(char *number)
{
    int diorange;

    diorange = atoi(number);

    if(diorange < 1 || diorange > 8)
    {
        printf("Diorank range is 1-8.\n");
        printf_help(0);
        exit(EXIT_FAILURE);

    }
	return diorange;
}

int CioRange(char *number)
{
    int nCIO;

    nCIO = atoi(number);

    if(nCIO < 1 || nCIO > 2)
    {
        printf("CIO port is 1 or 2.\n");

        printf_help(0);
        exit(EXIT_FAILURE);

    }

	return nCIO;
}

void mode_flash()
{

}

int main(int argc, char *argv[])
{

	iopl(3);                        //I/O Port Permissions

	int opt, option_index;
	int pin_number=0;
	double  t_off=0,t_on=0;
	BYTE pin_data=0;
	char pin_status;

	const char *short_options = "hr:w:s:o:mWR";

	static struct option long_options[] = {             //long_options
        {"help",	no_argument,        NULL,	'h'},   //0:no_argument, 1:required_argument they define in "getopt.h"
        {"read",	required_argument,  NULL,	'r'},
        {"write",	required_argument,  NULL,	'w'},
        {"set",		required_argument,  NULL,	's'},
        {"DO",		required_argument,  NULL,	'o'},
        {NULL, 0, 0, '\0'}
    };

	strcpy(program_name, argv[0]);
	if (argc == 1) printf_help(1);

    while((opt = getopt_long(argc, argv, short_options,long_options, &option_index)) != -1)
	{
		switch(opt){
			case 'h':
				printf_help(0);
				break;

            case 'r':
				pin_status='r';
				pin_number=DioRange(optarg);
				printf("pin_number  = %d \n",pin_number);
				break;

			case 'R':
				pin_status='R';
				break;

			case 'w':
				pin_status='w';
				pin_number=DioRange(optarg);
				//printf("optarg = %s\n",optarg);
				printf("pin_number  = %d \n",pin_number);
				break;

			case 'W':
				pin_status='W';
				break;

			case 's':
				if((*optarg == 'h')||(*optarg == 'H'))
					pin_data=true;
				else if((*optarg == 'l')||(*optarg == 'L'))
					pin_data=false;
				else
				{
					pin_data=htoi(optarg);
					//printf("pin_data = %d \n",pin_data);
                }
				break;

			case 'm':
				if (argc < 5)
				{
					printf_help(1);
				}
				pin_status='m';
				pin_number=DioRange(argv[2]);
				t_off=atof(argv[3]);
				t_on=atof(argv[4]);
				printf("pin_number= %d \n",pin_number);
				printf("t_off =%.2f , t_on=%.2f \n",t_off,t_on);
				break;
			/*case '?':
                if(optopt != 'e' && optopt != 'P')
                {
                    fprintf(stderr, "%s: Error - No such options: '%c'\n\n", program_name, optopt);
                }

				printf_help(0);
				break;*/

            case 'o':
				pin_status='o';
				pin_number = CioRange(optarg);

				//printf("CIO = %d \n",pin_number);
				break;

			default :
				printf("getopt return code 0x%o \n",opt);

				printf_help(0);
				break;
		}
	}

	//======================================================//
	if(SMBus_Install())
	{
		printf("SMBus_Install success \n");
		//return 0;
	}
	else
	{
		printf("SMBus_Install fail \n");
		return 0;
	}

	//======================================================//
	//m_F75111.bAddress=0x6e; //CIO116-G
	m_F75111.bAddress=0x9c; //on Board F75111

	if(!F75111_Init())
	{
		printf("F75111 init fail , m_F75111.bAddress= 0x%x\n",m_F75111.bAddress);

		//SMBus_Uninstall();
		exit(0);
	}

	//======================================================//
	switch(pin_status){
		case 'r':
			printf("get single digatal input pin_number = %d \n",pin_number);
			printf("pin_number %d = %d \n",pin_number ,F75111_GetDigitalInput_Pin(pin_number));
			break;

		case 'R':
			printf("get all digatal input \n");
			printf("input data = 0x%x \n",F75111_GetDigitalInput());
			break;

		case 'w':
			printf("pin_number = %d , pin_data = 0x%x \n",pin_number,pin_data );
			F75111_SetDigitalOutput_Pin(pin_number,pin_data);
			break;

		case 'W':
			printf("Set all digital output = 0x%x\n",pin_data);
			F75111_SetDigitalOutput(pin_data);
			break;

		case 'm':
			while(1)
			{
				printf("pin_number %d t_on \n",pin_number);
				F75111_SetDigitalOutput_Pin(pin_number,false);
				usleep(t_on*1000000);

				printf("pin_number %d t_off \n",pin_number);
				F75111_SetDigitalOutput_Pin(pin_number,true);
				usleep(t_off*1000000);
			}
			break;

        case 'o':
            //pin_data &= 0xF;

			if(pin_number == 1)
			{
                F75111_4I4O_Init();
                F75111_SetDigitalOutput_4I4O(pin_data);
                printf("Output CIO1_data(0x%x) \n", pin_data);
			}


            else if(pin_number == 2)
            {
                F75111_8I8O_Init();
                F75111_SetDigitalOutput_8I8O(pin_data);
                printf("Output (CIO1+CIO2)_data(0x%x) \n", pin_data);
            }


            else
                printf("CIO is out of range. (F75111 only CIO1 or CIO2)");

			break;

    }

    //======================================================//
 	SMBus_Uninstall();
    //printf_help(0);
	return 0;
}




