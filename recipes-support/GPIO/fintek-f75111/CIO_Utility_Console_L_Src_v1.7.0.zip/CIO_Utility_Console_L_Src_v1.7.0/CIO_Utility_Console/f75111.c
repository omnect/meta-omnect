// SMBus.cpp: implementation of the SMBus class.
//
//////////////////////////////////////////////////////////////////////
#include "SMBus/SMBus.h"
#include "f75111.h"
//#include <stdio.h>
#include<stdbool.h>

F75111_Address m_F75111;

bool F75111_Init()
{
    //if(PCI_AutoDetect())
    {
        if(SMBus_CheckChip(m_F75111.bAddress, F75111_DEVICE_ID, F75111_CHIP_ID_REGISTER_2, F75111_CHIP_ID_REGISTER_1))
        {
            //printf("chip detect 0x%x",m_F75111.bAddress);
            BYTE byteGPIO1X = 0;

            SMBus_ReadByte(m_F75111.bAddress,GPIO1X_OUTPUT_DATA,&byteGPIO1X) ;
            SMBus_WriteByte(m_F75111.bAddress, GPIO1X_CONTROL_MODE,(byteGPIO1X & 0x0f));
            SMBus_WriteByte(m_F75111.bAddress, GPIO1X_OUTPUT_DRIVING, (byteGPIO1X & 0x0f));

            SMBus_WriteByte(m_F75111.bAddress, GPIO2X_CONTROL_MODE, 0xFF);
            SMBus_WriteByte(m_F75111.bAddress, GPIO2X_OUTPUT_DRIVING, 0xFF);

            SMBus_WriteByte(m_F75111.bAddress, GPIO3X_CONTROL_MODE, 0x00);

            SMBus_WriteByte(m_F75111.bAddress,F75111_CONFIGURATION,0x03);
            SMBus_WriteByte(m_F75111.bAddress, 0x06, 0x04);

            return true;
        }
        else
        {
            printf("chip not detect 0x%x",m_F75111.bAddress);
            return false;
        }
    }
    /*else
    {
        {
            printf("PCI Autodect error\n");
        }
        return false;
    }*/
}


bool F75111_4I4O_Init()
{

    if (SMBus_CheckChip(m_F75111.bAddress, F75111_DEVICE_ID, F75111_CHIP_ID_REGISTER_2, F75111_CHIP_ID_REGISTER_1))
    {
        BYTE byteGPIO1X = 0;
        BYTE byteGPIO2X = 0;

        SMBus_ReadByte(m_F75111.bAddress, GPIO1X_CONTROL_MODE,&byteGPIO1X);
        SMBus_WriteByte(m_F75111.bAddress, GPIO1X_CONTROL_MODE,(byteGPIO1X & 0x0f));
        //SMBus_WriteByte(m_F75111.bAddress, GPIO1X_OUTPUT_DRIVING, (byteGPIO1X & 0x0f));

        SMBus_ReadByte(m_F75111.bAddress, GPIO2X_CONTROL_MODE, &byteGPIO2X);
        SMBus_WriteByte(m_F75111.bAddress, GPIO2X_CONTROL_MODE, byteGPIO2X | 0x87);
        SMBus_WriteByte(m_F75111.bAddress, GPIO2X_OUTPUT_DRIVING, byteGPIO2X | 0x87);

        SMBus_WriteByte(m_F75111.bAddress, F75111_CONFIGURATION, 0x03);
        SMBus_WriteByte(m_F75111.bAddress, 0x06, 0x04);

        return true;
    }
    return false;
}

bool F75111_8I8O_Init() //CIO1 = 8I CIO2 =8O
{
    BYTE byteGPIO1X = 0;

    if (SMBus_CheckChip(m_F75111.bAddress, F75111_DEVICE_ID, F75111_CHIP_ID_REGISTER_2, F75111_CHIP_ID_REGISTER_1))
    {
        SMBus_ReadByte(m_F75111.bAddress, GPIO1X_CONTROL_MODE,	&byteGPIO1X);
        SMBus_WriteByte(m_F75111.bAddress, GPIO1X_CONTROL_MODE, (byteGPIO1X & 0x0f) | 0x20);
        SMBus_WriteByte(m_F75111.bAddress, GPIO1X_OUTPUT_DRIVING, (byteGPIO1X & 0x0f) | 0x20);

        SMBus_WriteByte(m_F75111.bAddress, GPIO2X_CONTROL_MODE,	0x78);
        SMBus_WriteByte(m_F75111.bAddress, GPIO2X_OUTPUT_DRIVING, 0x78);

        SMBus_WriteByte(m_F75111.bAddress, GPIO3X_CONTROL_MODE,	0x0E);
        SMBus_WriteByte(m_F75111.bAddress, GPIO3X_OUTPUT_DRIVING, 0x0E);

        SMBus_WriteByte(m_F75111.bAddress, F75111_CONFIGURATION, 0x03);
        SMBus_WriteByte(m_F75111.bAddress, 0x06, 0x04);

        return true;
    }

    return false;
}


BYTE F75111_GetDigitalInput ()
{
    BYTE byteGPIO1X = 0;
    BYTE byteGPIO3X = 0;
    BYTE byteData   = 0;

    SMBus_ReadByte(m_F75111.bAddress,GPIO1X_INPUT_DATA,&byteGPIO1X) ;
    SMBus_ReadByte(m_F75111.bAddress,GPIO3X_INPUT_DATA,&byteGPIO3X) ;
    byteGPIO1X = byteGPIO1X  & 0xF0;
    byteGPIO3X = byteGPIO3X  & 0x0F;

    byteData = ( byteGPIO1X & 0x10 )? byteData + 0x01 : byteData;
    byteData = ( byteGPIO1X & 0x80 )? byteData + 0x02 : byteData;
    byteData = ( byteGPIO1X & 0x40 )? byteData + 0x04 : byteData;
    byteData = ( byteGPIO3X & 0x01 )? byteData + 0x08 : byteData;

    byteData = ( byteGPIO3X & 0x02 )? byteData + 0x10 : byteData;
    byteData = ( byteGPIO3X & 0x04 )? byteData + 0x20 : byteData;
    byteData = ( byteGPIO3X & 0x08 )? byteData + 0x40 : byteData;
    byteData = ( byteGPIO1X & 0x20 )? byteData + 0x80 : byteData;

    return byteData;
}

BYTE F75111_GetDigitalInput_4I4O()//得到F75111 SMBUS初始值
{
    BYTE byteGPIO1X = 0;
    BYTE byteGPIO3X = 0;
    BYTE byteData = 0;

    SMBus_ReadByte(m_F75111.bAddress, GPIO1X_INPUT_DATA, &byteGPIO1X); //讀出GPIO1X_INPUT_DATA原本腳位數值存入變數byteGPIO1X
    SMBus_ReadByte(m_F75111.bAddress, GPIO3X_INPUT_DATA, &byteGPIO3X);	//讀出GPIO3X_INPUT_DATA原本腳位數值存入變數byteGPIO3X

    byteGPIO1X = byteGPIO1X & 0xD0;//保留GPIO14-17原本狀態,GPIO10-13歸0
    byteGPIO3X = byteGPIO3X & 0x01;//保留GPIO30-33原本狀態,GPIO34-37歸0

    //4DI只有上面四支腳位
    //要確保GPIO14 GPIO17 GPIO16 GPIO30 腳位狀態被保留
    byteData = (byteGPIO1X & 0x10) ? byteData + 0x01 : byteData;
    byteData = (byteGPIO1X & 0x80) ? byteData + 0x02 : byteData;
    byteData = (byteGPIO1X & 0x40) ? byteData + 0x04 : byteData;
    byteData = (byteGPIO3X & 0x01) ? byteData + 0x08 : byteData;
    byteData = byteData & 0x0F;
    return byteData;
}

BYTE F75111_GetDigitalInput_8I8O()//用於 CIO1 = 8I CIO2 =8O
{
    BYTE byteGPIO1X = 0;
    BYTE byteGPIO2X = 0;
    BYTE byteGPIO3X = 0;
    BYTE byteData = 0;

    SMBus_ReadByte(m_F75111.bAddress, GPIO1X_INPUT_DATA, &byteGPIO1X);
    SMBus_ReadByte(m_F75111.bAddress, GPIO2X_INPUT_DATA, &byteGPIO2X);
    SMBus_ReadByte(m_F75111.bAddress, GPIO3X_INPUT_DATA, &byteGPIO3X);

    byteGPIO1X = byteGPIO1X & 0xD0;
    byteGPIO2X = byteGPIO2X & 0x87;
    byteGPIO3X = byteGPIO3X & 0x01;

    byteData = (byteGPIO1X & 0x10) ? byteData + 0x01 : byteData; //Di0
    byteData = (byteGPIO1X & 0x80) ? byteData + 0x02 : byteData;//Di1
    byteData = (byteGPIO1X & 0x40) ? byteData + 0x04 : byteData;//Di2
    byteData = (byteGPIO3X & 0x01) ? byteData + 0x08 : byteData;//Di3

    byteData = (byteGPIO2X & 0x01) ? byteData + 0x10 : byteData;//Di4
    byteData = (byteGPIO2X & 0x02) ? byteData + 0x20 : byteData;//Di5
    byteData = (byteGPIO2X & 0x04) ? byteData + 0x40 : byteData;//Di6
    byteData = (byteGPIO2X & 0x80) ? byteData + 0x80 : byteData;//Di7

    return byteData;
}

void F75111_SetDigitalOutput(BYTE byteValue)
{
    BYTE byteData = 0;

    byteData = (byteValue & 0x01 )? byteData + 0x01 : byteData;
    byteData = (byteValue & 0x02 )? byteData + 0x02 : byteData;
    byteData = (byteValue & 0x04 )? byteData + 0x04 : byteData;
    byteData = (byteValue & 0x80 )? byteData + 0x08 : byteData;

    byteData = (byteValue & 0x40 )? byteData + 0x10 : byteData;
    byteData = (byteValue & 0x20 )? byteData + 0x20 : byteData;
    byteData = (byteValue & 0x10 )? byteData + 0x40 : byteData;
    byteData = (byteValue & 0x08 )? byteData + 0x80 : byteData;

    SMBus_WriteByte(m_F75111.bAddress,GPIO2X_OUTPUT_DATA,byteData);
    usleep(10);
}

void F75111_SetDigitalOutput_4I4O(BYTE byteValue)//20190828 add by Nico
{
    BYTE byteData = 0;
    BYTE byteGPIO2X = 0;
    SMBus_ReadByte(m_F75111.bAddress,GPIO2X_OUTPUT_DATA,&byteGPIO2X) ;

    byteData = (byteValue & 0x01 )? byteData + 0x01 : byteData;
    byteData = (byteValue & 0x02 )? byteData + 0x02 : byteData;
    byteData = (byteValue & 0x04 )? byteData + 0x04 : byteData;
    byteData = (byteValue & 0x08 )? byteData + 0x80 : byteData;
    //byteData = byteGPIO2X | byteData;

    SMBus_WriteByte(m_F75111.bAddress,GPIO2X_OUTPUT_DATA,byteData);
    usleep(10);
}

void F75111_SetDigitalOutput_8I8O(BYTE byteValue)
{
    BYTE byteGPIO1X = 0;
    BYTE byteData1x = 0;
    BYTE byteData2x = 0;
    BYTE byteData3x = 0;

    byteData3x = (byteValue & 0x01) ? byteData3x + 0x02 : byteData3x;//new	//Do0 GPIO31
    byteData3x = (byteValue & 0x02) ? byteData3x + 0x04 : byteData3x;		//Do1 GPIO32
    byteData3x = (byteValue & 0x04) ? byteData3x + 0x08 : byteData3x;		//Do2 GPIO33

    byteData1x = (byteValue & 0x08) ? byteData1x + 0x20 : byteData1x;		//Do3 GPIO15

    byteData2x = (byteValue & 0x10) ? byteData2x + 0x40 : byteData2x;		//Do4 GPIO26
    byteData2x = (byteValue & 0x20) ? byteData2x + 0x20 : byteData2x;		//Do5 GPIO25
    byteData2x = (byteValue & 0x40) ? byteData2x + 0x10 : byteData2x;		//Do6 GPIO24
    byteData2x = (byteValue & 0x80) ? byteData2x + 0x08	: byteData2x;		//Do7 GPIO23

    //byteData2x = (byteValue & 0x08 )? byteData2x + 0x80 : byteData2x;		//old

    SMBus_ReadByte(m_F75111.bAddress, GPIO1X_OUTPUT_DATA, &byteGPIO1X);
    byteGPIO1X = byteGPIO1X & 0x0F;

    SMBus_WriteByte(m_F75111.bAddress, GPIO1X_OUTPUT_DATA, byteData1x | byteGPIO1X);
    SMBus_WriteByte(m_F75111.bAddress, GPIO2X_OUTPUT_DATA, byteData2x);
    SMBus_WriteByte(m_F75111.bAddress, GPIO3X_OUTPUT_DATA, byteData3x);
}

void F75111_SetDigitalOutput_1i1o(BYTE byteValue)
{
    BYTE byteData = 0;
    BYTE byteGPIO2X = 0;

    SMBus_ReadByte(m_F75111.bAddress, GPIO2X_OUTPUT_DATA, &byteGPIO2X);
    byteData = (byteValue & 0x01) ? byteData + 0x01 : byteData; //GPIO20 ，控制GPIO20
    byteData = (byteGPIO2X & 0x02) ? byteData + 0x02 : byteData;//GPIO21 ，保留GPIO21-GPIO27原本狀態
    byteData = (byteGPIO2X & 0x04) ? byteData + 0x04 : byteData;//GPIO22 ，保留GPIO21-GPIO27原本狀態
    byteData = (byteGPIO2X & 0x80) ? byteData + 0x08 : byteData;//GPIO27 ，保留GPIO21-GPIO27原本狀態
    byteData = (byteGPIO2X & 0x40) ? byteData + 0x10 : byteData;//GPIO26 ，保留GPIO21-GPIO27原本狀態
    byteData = (byteGPIO2X & 0x20) ? byteData + 0x20 : byteData;//GPIO25 ，保留GPIO21-GPIO27原本狀態
    byteData = (byteGPIO2X & 0x10) ? byteData + 0x40 : byteData;//GPIO24 ，保留GPIO21-GPIO27原本狀態
    byteData = (byteGPIO2X & 0x08) ? byteData + 0x80 : byteData;//GPIO23 ，保留GPIO21-GPIO27原本狀態
    SMBus_WriteByte(m_F75111.bAddress, GPIO2X_OUTPUT_DATA, byteData);
}

void F75111_SetWDTinit ()
{
     SMBus_WriteByte(m_F75111.bAddress, F75111_CONFIGURATION, 0x03);
     SMBus_WriteByte(m_F75111.bAddress, 0x06, 0x04);
}


void F75111_SetWDTEnable (BYTE byteTimer)
{
    SMBus_WriteByte(m_F75111.bAddress,WDT_TIMER_RANGE  ,byteTimer);
    usleep(10);
    SMBus_WriteByte(m_F75111.bAddress,WDT_CONFIGURATION,WDT_TIMEOUT_FLAG | WDT_ENABLE | WDT_PULSE | WDT_PSWIDTH_100MS);
}

void F75111_SetWDTDisable ()
{
    SMBus_WriteByte(m_F75111.bAddress,WDT_CONFIGURATION,0x00);
}

BYTE F75111_GetDigitalInput_Pin (int nPin)
{
    BYTE byteVal = F75111_GetDigitalInput();
    BYTE bytePin = (((byteVal >> nPin) & 0x01) << nPin);

    return bytePin;
}

void F75111_SetDigitalOutput_Pin(int nPin, bool bStatus)
{
    BYTE byteValue = 0x0;
    byteValue |= (1 << nPin);

    if(bStatus == false)
        byteValue -= (1 << nPin);

    F75111_SetDigitalOutput(byteValue);
}


